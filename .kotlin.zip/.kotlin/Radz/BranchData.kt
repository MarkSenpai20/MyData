package com.example.queueless_practice2.Database

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper

class BranchData(context: Context){


package com.example.queueless.database

import android.content.ContentValues
import android.content.Context

class SetupData(context: Context) {

    private val dbHelper = DatabaseHelper(context)

    // ✅ Insert Branches (Run Once)
    fun insertBranches() {
        val db = dbHelper.writableDatabase

        val branches = listOf(
            Triple("Baguio Main Branch", "Baguio City", 15),
            Triple("La Union Branch", "San Fernando", 20),
            Triple("Laoag Branch", "Ilocos Norte", 10)
        )

        for (branch in branches) {
            val values = ContentValues().apply {
                put(DatabaseHelper.BRANCH_NAME, branch.first)
                put(DatabaseHelper.LOCATION, branch.second)
                put(DatabaseHelper.EST_WAIT_TIME, branch.third)
                put(DatabaseHelper.CURRENT_QUEUE, 1)
            }
            db.insert(DatabaseHelper.TABLE_BRANCHES, null, values)
        }

        db.close()
    }

    // ✅ Insert Services (Per Branch)
    fun insertServices() {
        val db = dbHelper.writableDatabase

        val services = listOf(
            // branchId, name, process time, capacity
            arrayOf(1, "New Application", 15, 30),
            arrayOf(1, "Renewal", 10, 40),
            arrayOf(1, "Payment", 5, 60),
            arrayOf(1, "Technical Assistance", 20, 20),

            arrayOf(2, "New Application", 15, 30),
            arrayOf(2, "Renewal", 10, 40),
            arrayOf(2, "Payment", 5, 60),
            arrayOf(2, "Technical Assistance", 20, 20),

            arrayOf(3, "New Application", 15, 25),
            arrayOf(3, "Renewal", 10, 35),
            arrayOf(3, "Payment", 5, 50),
            arrayOf(3, "Technical Assistance", 20, 15)
        )

        for (s in services) {
            val v = ContentValues().apply {
                put(DatabaseHelper.SERVICE_BRANCH_ID, s[0] as Int)
                put(DatabaseHelper.SERVICE_NAME, s[1] as String)
                put(DatabaseHelper.PROCESS_TIME, s[2] as Int)
                put(DatabaseHelper.DAILY_CAPACITY, s[3] as Int)
            }
            db.insert(DatabaseHelper.TABLE_SERVICES, null, v)
        }

        db.close()
    }
}
// Call this once main

val setup = SetupData(this)
setup.insertBranches()
setup.insertServices()


//bookingDao
package com.example.queueless.database

import android.content.ContentValues
import android.content.Context

class BookingDao(context: Context) {

    private val dbHelper = DatabaseHelper(context)

    // ✅ Auto-generate Queue Number
    private fun getNextQueueNumber(
        serviceId: Int,
        date: String
    ): Int {

        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT MAX(${DatabaseHelper.QUEUE_NUMBER})
            FROM ${DatabaseHelper.TABLE_BOOKINGS}
            WHERE ${DatabaseHelper.BOOK_SERVICE_ID}=?
            AND ${DatabaseHelper.BOOK_DATE}=?
            """.trimIndent(),
            arrayOf(serviceId.toString(), date)
        )

        val next = if (cursor.moveToFirst()) {
            cursor.getInt(0) + 1
        } else {
            1
        }

        cursor.close()
        db.close()
        return next
    }

    // ✅ Check Daily Capacity
    private fun isCapacityAvailable(serviceId: Int, date: String): Boolean {
        val db = dbHelper.readableDatabase

        val capacityCursor = db.rawQuery(
            "SELECT ${DatabaseHelper.DAILY_CAPACITY} FROM ${DatabaseHelper.TABLE_SERVICES} WHERE ${DatabaseHelper.SERVICE_ID}=?",
            arrayOf(serviceId.toString())
        )

        capacityCursor.moveToFirst()
        val capacity = capacityCursor.getInt(0)
        capacityCursor.close()

        val countCursor = db.rawQuery(
            """
            SELECT COUNT(*) FROM ${DatabaseHelper.TABLE_BOOKINGS}
            WHERE ${DatabaseHelper.BOOK_SERVICE_ID}=?
            AND ${DatabaseHelper.BOOK_DATE}=?
            AND ${DatabaseHelper.STATUS}='ACTIVE'
            """.trimIndent(),
            arrayOf(serviceId.toString(), date)
        )

        countCursor.moveToFirst()
        val booked = countCursor.getInt(0)
        countCursor.close()
        db.close()

        return booked < capacity
    }

    // ✅ Book Service
    fun bookService(
        userId: Int,
        branchId: Int,
        serviceId: Int,
        date: String,
        timeSlot: String
    ): Boolean {

        if (!isCapacityAvailable(serviceId, date)) return false

        val queueNum = getNextQueueNumber(serviceId, date)
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(DatabaseHelper.BOOK_USER_ID, userId)
            put(DatabaseHelper.BOOK_BRANCH_ID, branchId)
            put(DatabaseHelper.BOOK_SERVICE_ID, serviceId)
            put(DatabaseHelper.BOOK_DATE, date)
            put(DatabaseHelper.BOOK_TIME, timeSlot)
            put(DatabaseHelper.QUEUE_NUMBER, queueNum)
            put(DatabaseHelper.CURRENT_SERVED, 1)
            put(DatabaseHelper.STATUS, "ACTIVE")
        }

        val result = db.insert(DatabaseHelper.TABLE_BOOKINGS, null, values)
        db.close()

        return result != -1L
    }
}
fun moveQueue(bookingId: Int): Boolean {
    val db = dbHelper.writableDatabase
    val result = db.execSQL(
        """
        UPDATE ${DatabaseHelper.TABLE_BOOKINGS}
        SET ${DatabaseHelper.CURRENT_SERVED} =
        ${DatabaseHelper.CURRENT_SERVED} + 1
        WHERE ${DatabaseHelper.BOOKING_ID} = ?
        """.trimIndent(),
        arrayOf(bookingId)
    )
    db.close()
    return true
}
// cancel queue
fun cancelBooking(bookingId: Int): Boolean {
    val db = dbHelper.writableDatabase

    val values = ContentValues().apply {
        put(DatabaseHelper.STATUS, "CANCELLED")
    }

    val result = db.update(
        DatabaseHelper.TABLE_BOOKINGS,
        values,
        "${DatabaseHelper.BOOKING_ID}=? AND ${DatabaseHelper.STATUS}='ACTIVE'",
        arrayOf(bookingId.toString())
    )

    db.close()
    return result > 0
}
//complete
fun cancelBooking(bookingId: Int): Boolean {
    val db = dbHelper.writableDatabase

    val values = ContentValues().apply {
        put(DatabaseHelper.STATUS, "CANCELLED")
    }

    val result = db.update(
        DatabaseHelper.TABLE_BOOKINGS,
        values,
        "${DatabaseHelper.BOOKING_ID}=? AND ${DatabaseHelper.STATUS}='ACTIVE'",
        arrayOf(bookingId.toString())
    )

    db.close()
    return result > 0
}
fun cancelBooking(bookingId: Int): Boolean {
    val db = dbHelper.writableDatabase

    val values = ContentValues().apply {
        put(DatabaseHelper.STATUS, "CANCELLED")
    }

    val result = db.update(
        DatabaseHelper.TABLE_BOOKINGS,
        values,
        "${DatabaseHelper.BOOKING_ID}=? AND ${DatabaseHelper.STATUS}='ACTIVE'",
        arrayOf(bookingId.toString())
    )

    db.close()
    return result > 0
}
fun getBookingHistory(userId: Int) =
    dbHelper.readableDatabase.rawQuery(
        """
        SELECT * FROM ${DatabaseHelper.TABLE_BOOKINGS}
        WHERE ${DatabaseHelper.BOOK_USER_ID}=?
        AND ${DatabaseHelper.STATUS}!='ACTIVE'
        """.trimIndent(),
        arrayOf(userId.toString())
    )
}

package com.example.queueless.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "queueless.db"
        private const val DATABASE_VERSION = 1

        // USERS TABLE
        const val TABLE_USERS = "users"
        const val USER_ID = "user_id"
        const val FULL_NAME = "full_name"
        const val CONTACT = "contact"

        // BRANCHES TABLE
        const val TABLE_BRANCHES = "branches"
        const val BRANCH_ID = "branch_id"
        const val BRANCH_NAME = "branch_name"
        const val LOCATION = "location"
        const val EST_WAIT_TIME = "estimated_wait_time"
        const val CURRENT_QUEUE = "current_queue"

        // SERVICES TABLE
        const val TABLE_SERVICES = "services"
        const val SERVICE_ID = "service_id"
        const val SERVICE_NAME = "service_name"
        const val PROCESS_TIME = "process_time"
        const val DAILY_CAPACITY = "daily_capacity"
        const val SERVICE_BRANCH_ID = "branch_id"

        // BOOKINGS TABLE
        const val TABLE_BOOKINGS = "bookings"
        const val BOOKING_ID = "booking_id"
        const val BOOK_USER_ID = "user_id"
        const val BOOK_BRANCH_ID = "branch_id"
        const val BOOK_SERVICE_ID = "service_id"
        const val BOOK_DATE = "date"
        const val BOOK_TIME = "time_slot"
        const val QUEUE_NUMBER = "queue_number"
        const val CURRENT_SERVED = "current_served"
        const val STATUS = "status"
    }

    override fun onCreate(db: SQLiteDatabase) {

        val createUsers = """
            CREATE TABLE $TABLE_USERS (
                $USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $FULL_NAME TEXT NOT NULL,
                $CONTACT TEXT NOT NULL UNIQUE
            )
        """.trimIndent()

        val createBranches = """
            CREATE TABLE $TABLE_BRANCHES (
                $BRANCH_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $BRANCH_NAME TEXT NOT NULL,
                $LOCATION TEXT NOT NULL,
                $EST_WAIT_TIME INTEGER,
                $CURRENT_QUEUE INTEGER
            )
        """.trimIndent()

        val createServices = """
            CREATE TABLE $TABLE_SERVICES (
                $SERVICE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $SERVICE_NAME TEXT NOT NULL,
                $PROCESS_TIME INTEGER,
                $DAILY_CAPACITY INTEGER,
                $SERVICE_BRANCH_ID INTEGER,
                FOREIGN KEY($SERVICE_BRANCH_ID) 
                REFERENCES $TABLE_BRANCHES($BRANCH_ID)
            )
        """.trimIndent()

        val createBookings = """
            CREATE TABLE $TABLE_BOOKINGS (
                $BOOKING_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $BOOK_USER_ID INTEGER,
                $BOOK_BRANCH_ID INTEGER,
                $BOOK_SERVICE_ID INTEGER,
                $BOOK_DATE TEXT,
                $BOOK_TIME TEXT,
                $QUEUE_NUMBER INTEGER,
                $CURRENT_SERVED INTEGER DEFAULT 0,
                $STATUS TEXT,
                FOREIGN KEY($BOOK_USER_ID) REFERENCES $TABLE_USERS($USER_ID),
                FOREIGN KEY($BOOK_BRANCH_ID) REFERENCES $TABLE_BRANCHES($BRANCH_ID),
                FOREIGN KEY($BOOK_SERVICE_ID) REFERENCES $TABLE_SERVICES($SERVICE_ID)
            )
        """.trimIndent()

        db.execSQL(createUsers)
        db.execSQL(createBranches)
        db.execSQL(createServices)
        db.execSQL(createBookings)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BOOKINGS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_SERVICES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BRANCHES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }
}
